
# Student Management System

A Java console-based application to manage student records.

## Features
- Add Student
- View Students
- Search Student
- Delete Student

## Technologies
- Java
- OOP
- ArrayList

## How to Run
1. Compile all files
2. Run Main.java
