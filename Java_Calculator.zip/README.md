# Java Calculator

This is a simple calculator program written in Java.

## Features
- Addition
- Subtraction
- Multiplication
- Division

## How to Run
1. Compile the program:
   javac Calculator.java
2. Run the program:
   java Calculator

Perfect for beginners and GitHub projects.
