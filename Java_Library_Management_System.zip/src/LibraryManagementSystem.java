
import java.util.ArrayList;
import java.util.Scanner;

class Book {
    int id;
    String title;
    boolean issued;

    Book(int id, String title) {
        this.id = id;
        this.title = title;
        this.issued = false;
    }
}

public class LibraryManagementSystem {
    static ArrayList<Book> books = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;

        do {
            System.out.println("\n=== Library Management System ===");
            System.out.println("1. Add Book");
            System.out.println("2. View Books");
            System.out.println("3. Issue Book");
            System.out.println("4. Return Book");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1: addBook(); break;
                case 2: viewBooks(); break;
                case 3: issueBook(); break;
                case 4: returnBook(); break;
                case 5: System.out.println("Thank you!"); break;
                default: System.out.println("Invalid choice");
            }
        } while (choice != 5);
    }

    static void addBook() {
        System.out.print("Enter book id: ");
        int id = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter book title: ");
        String title = sc.nextLine();
        books.add(new Book(id, title));
        System.out.println("Book added successfully.");
    }

    static void viewBooks() {
        System.out.println("\nBook List:");
        for (Book b : books) {
            System.out.println(b.id + " | " + b.title + " | " + (b.issued ? "Issued" : "Available"));
        }
    }

    static void issueBook() {
        System.out.print("Enter book id to issue: ");
        int id = sc.nextInt();
        for (Book b : books) {
            if (b.id == id && !b.issued) {
                b.issued = true;
                System.out.println("Book issued successfully.");
                return;
            }
        }
        System.out.println("Book not available.");
    }

    static void returnBook() {
        System.out.print("Enter book id to return: ");
        int id = sc.nextInt();
        for (Book b : books) {
            if (b.id == id && b.issued) {
                b.issued = false;
                System.out.println("Book returned successfully.");
                return;
            }
        }
        System.out.println("Invalid book id.");
    }
}
