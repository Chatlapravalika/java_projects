
Java Library Management System

Description:
A console-based Library Management System using Java.

Features:
- Add books
- View books
- Issue books
- Return books

Concepts Used:
- OOP (Classes & Objects)
- ArrayList
- Scanner
- Loops & Conditions

How to Run:
1. Open terminal in src folder
2. Compile: javac LibraryManagementSystem.java
3. Run: java LibraryManagementSystem
