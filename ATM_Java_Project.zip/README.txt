
ATM Management System - Java Project

How to run:

1. Extract ZIP
2. Open Command Prompt in this folder
3. Compile:
   javac ATM.java
4. Run:
   java ATM

Login PIN: 1234
Initial Balance: 10000

This is a console-based Java project for practice and resume.
